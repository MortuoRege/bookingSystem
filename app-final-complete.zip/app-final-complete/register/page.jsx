// app/register/page.jsx
import RegisterPage from "../components/register"; // adjust path/name

export default function Page() {
  return <RegisterPage />;
}
