// app/my-appointments/page.jsx
import MyAppointmentsPage from "../components/user/my-appointments";

export default function Page() {
  return <MyAppointmentsPage />;
}
