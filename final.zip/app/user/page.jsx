// app/providers/page.jsx
"use client";

import UserProvidersPage from "../components/user/providers";

export default function ProvidersPage() {
  return <UserProvidersPage />;
}
