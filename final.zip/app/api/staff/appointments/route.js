// app/api/staff/appointments/route.js
import { prisma } from "../../../prisma";
import { cookies } from "next/headers";

function jsonSafe(value) {
  return JSON.parse(
    JSON.stringify(value, (_, v) => (typeof v === "bigint" ? v.toString() : v)),
  );
}

// GET appointments for the currently logged-in staff member
export async function GET(req) {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get("userId")?.value;

    if (!userId) {
      return Response.json({ error: "Not authenticated" }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const statusFilter = searchParams.get("status");

    // Build where clause - MUST include staff_id matching current user
    const whereClause = {
      staff_id: BigInt(userId),
      ...(statusFilter && statusFilter !== "all" ? { status: statusFilter } : {}),
    };

    const appointments = await prisma.appointments.findMany({
      where: whereClause,
      include: {
        users_appointments_customer_idTousers: {
          select: {
            id: true,
            full_name: true,
            email: true,
          },
        },
      },
      orderBy: { starts_at: "asc" },
    });

    // Transform to cleaner format
    const formattedAppointments = appointments.map((apt) => ({
      id: apt.id.toString(),
      patient: {
        id: apt.users_appointments_customer_idTousers.id.toString(),
        name: apt.users_appointments_customer_idTousers.full_name,
        email: apt.users_appointments_customer_idTousers.email,
      },
      startsAt: apt.starts_at,
      endsAt: apt.ends_at,
      status: apt.status,
      createdAt: apt.created_at,
    }));

    return Response.json(jsonSafe({ appointments: formattedAppointments }));
  } catch (error) {
    console.error("Error fetching staff appointments:", error);
    return Response.json({ error: "Server error" }, { status: 500 });
  }
}

// PATCH - Update appointment status (staff can update their own appointments)
export async function PATCH(req) {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get("userId")?.value;

    if (!userId) {
      return Response.json({ error: "Not authenticated" }, { status: 401 });
    }

    const body = await req.json();
    const { appointmentId, status } = body;

    if (!appointmentId || !status) {
      return Response.json(
        { error: "appointmentId and status are required" },
        { status: 400 }
      );
    }

    const validStatuses = ["pending", "approved", "cancelled", "completed"];
    if (!validStatuses.includes(status)) {
      return Response.json(
        { error: "Invalid status. Must be: pending, approved, cancelled, or completed" },
        { status: 400 }
      );
    }

    // Verify this appointment belongs to the current staff member
    const appointment = await prisma.appointments.findUnique({
      where: { id: BigInt(appointmentId) },
    });

    if (!appointment) {
      return Response.json({ error: "Appointment not found" }, { status: 404 });
    }

    if (appointment.staff_id.toString() !== userId) {
      return Response.json(
        { error: "You can only update your own appointments" },
        { status: 403 }
      );
    }

    // Update the appointment
    const updated = await prisma.appointments.update({
      where: { id: BigInt(appointmentId) },
      data: { status },
    });

    return Response.json(jsonSafe({ ok: true, appointment: updated }));
  } catch (error) {
    console.error("Error updating appointment:", error);
    return Response.json({ error: "Server error" }, { status: 500 });
  }
}
