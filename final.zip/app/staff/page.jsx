import StaffPage from "../components/staff/StaffDashboard";

export default function Page() {
  return <StaffPage />;
}
