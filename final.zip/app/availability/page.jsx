import Availability from "../components/staff/availability";

export default function Page() {
  return <Availability />;
}
