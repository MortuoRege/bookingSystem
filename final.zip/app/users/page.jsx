// app/users/page.jsx
import UsersPage from "../components/admin/users";

export default function Page() {
  return <UsersPage />;
}
