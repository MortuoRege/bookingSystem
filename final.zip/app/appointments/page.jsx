// app/appointments/page.jsx
import AdminAppointments from "../components/admin/appointments";

export default function AppointmentsPage() {
  return <AdminAppointments />;
}
