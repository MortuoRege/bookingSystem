"use client";

import ProvidersPage from "../components/admin/providers";

export default function Page() {
  return <ProvidersPage />;
}
