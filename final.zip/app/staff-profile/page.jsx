import StaffProfile from "../components/staff/StaffProfile";

export default function Page() {
  return <StaffProfile />;
}
