// app/staff-appointments/page.jsx
import StaffAppointments from "../components/staff/StaffAppointments";

export default function StaffAppointmentsPage() {
  return <StaffAppointments />;
}
